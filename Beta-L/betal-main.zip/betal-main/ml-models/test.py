print("python")
